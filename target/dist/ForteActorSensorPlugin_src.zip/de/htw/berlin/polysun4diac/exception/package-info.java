/**
 * 
 */
/**
 * Package for library-specific exceptions
 */
package de.htw.berlin.polysun4diac.exception;