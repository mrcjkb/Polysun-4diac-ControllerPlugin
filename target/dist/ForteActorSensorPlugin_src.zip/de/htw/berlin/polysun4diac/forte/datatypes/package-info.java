/**
 * 
 */
/**
 * Package for the definitions of IEC 61499 data types.
 */
package de.htw.berlin.polysun4diac.forte.datatypes;