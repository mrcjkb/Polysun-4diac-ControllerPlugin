/**
 * 
 */
/**
 * PluginControllers for co-simulations between Polysun and 4diac
 * @author Marc Jakobi</p>HTW Berlin</p>July 2017
 * @see <a href="https://www.http://www.velasolaris.com/english/home.html">Polysun</a>
 * @see <a href="https://www.https://www.eclipse.org/4diac/">4diac</a>
 */
package de.htw.berlin.polysun4diac.plugins;